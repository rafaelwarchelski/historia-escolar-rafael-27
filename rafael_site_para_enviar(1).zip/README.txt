SITE ESCOLAR — RAFAEL DOS SANTOS WARCHELSKI

Arquivos:
- index.html (página inicial)
- css/style.css (estilo)
- js/script.js (15 cards, janela de leitura e voz)
- assets/rafael-foto.jpg (adicione aqui a foto do Rafael)

IMPORTANTE:
1. A foto não foi incluída neste pacote porque o arquivo original não pôde ser recuperado neste momento. Coloque a imagem na pasta assets e nomeie como rafael-foto.jpg.
2. Os 15 cards já existem; substitua os textos de exemplo no array 'redacoes' em js/script.js pelos textos verdadeiros.
3. A história de bullying e superação foi criada como narrativa ilustrativa. Rafael deve confirmar se ela corresponde à sua experiência antes de apresentá-la como autobiografia.

Para publicar no GitHub Pages, envie o conteúdo desta pasta para a raiz do repositório. Em Settings > Pages selecione Deploy from a branch, branch main e pasta /(root).
